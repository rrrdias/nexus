export default defineEventHandler(async (event) => {
  const issuer = process.env.OIDC_KEYCLOAK_ISSUER;
  let discovery = null;
  let discoveryError = null;

  if (issuer) {
    try {
      discovery = await $fetch(`${issuer}/.well-known/openid-configuration`);
    } catch (e: any) {
      discoveryError = {
        message: e.message,
        stack: e.stack
      };
    }
  }

  return {
    oidc: event.context.oidc,
    headers: getRequestHeaders(event),
    config: {
      issuer,
      discovery,
      discoveryError
    }
  }
})
