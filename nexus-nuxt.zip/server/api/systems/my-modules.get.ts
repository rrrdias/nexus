export default defineEventHandler(async (event) => {
  // Tenta obter a sessão de forma robusta usando o utilitário do módulo
  const session = await getUserSession(event);
  console.log('Full OIDC Session:', JSON.stringify(session, null, 2));

  if (!session || !session.loggedInAt) {
    console.error('Session not found or user not logged in');
    throw createError({
      statusCode: 401,
      statusMessage: "Sessão não encontrada ou expirada. Faça login novamente.",
    });
  }

  const userSession = session as any;
  console.log('User Session Object:', JSON.stringify(userSession, null, 2));

  // Busca o ID do usuário - tentando múltiplas propriedades comuns e aninhadas
  const userid = userSession?.userName || 
                 userSession?.preferred_username ||
                 userSession?.userInfo?.preferred_username || 
                 userSession?.userInfo?.userName ||
                 userSession?.userInfo?.sub ||
                 userSession?.sub ||
                 userSession?.email ||
                 userSession?.userInfo?.email;

  if (!userid) {
    console.error('User ID not found. Session structure:', JSON.stringify(userSession, null, 2));
    throw createError({
      statusCode: 401,
      statusMessage: "Usuário não identificado na sessão. Verifique os claims do Keycloak.",
    });
  }

  try {
    const userWithAccess = await prisma.user.findUnique({
      where: { userid: userid },
      include: {
        systemAccess: {
          include: { systemModule: true },
        },
      },
    });

    if (!userWithAccess) {
      throw createError({
        statusCode: 404,
        statusMessage: "Colaborador não encontrado.",
      });
    }

    return {
      success: true,
      user: {
        name: userWithAccess.name,
        role: userWithAccess.role,
        isActive: userWithAccess.isActive,
      },
      systems: userWithAccess.systemAccess.map((access) => access.systemModule),
    };
  } catch (error: any) {
    return createError({ statusCode: 500, statusMessage: "Erro interno." });
  }
});